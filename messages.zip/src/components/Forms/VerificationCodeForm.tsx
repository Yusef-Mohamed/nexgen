"use client";

import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import * as z from "zod";
import { axiosInstance } from "@/app/lib/utils";
import { toast } from "react-toastify";
import CustomForm from "./CustomForm";
import { useSearchParams } from "next/navigation";
import { buildAuthHref, getAuthRedirect } from "@/lib/authRedirect";

const VerificationCodeForm = () => {
  const t = useTranslations("ResetCode");
  const inputs = useTranslations("Forms");
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirect = getAuthRedirect(searchParams);

  const formSchema = z.object({
    otp: z.string().min(6, {
      message: inputs("otpMustBe6Digits"),
    }),
  });

  const onSubmit = async (data: z.infer<typeof formSchema>) => {
    await axiosInstance.post("/auth/verifyResetCode", {
      resetCode: data.otp,
    });
    router.push(buildAuthHref("/reset-password", redirect));
    toast.success(inputs("code_verified"));
  };

  const fields = [
    {
      type: "otp",
      label: inputs("code"),
      placeholder: inputs("code"),
      name: "otp" as const,
      required: true,
    },
  ];

  return (
    <CustomForm
      schema={formSchema}
      fields={fields}
      submitLabel={t("checkCode")}
      onSubmit={onSubmit}
    />
  );
};

export default VerificationCodeForm;
