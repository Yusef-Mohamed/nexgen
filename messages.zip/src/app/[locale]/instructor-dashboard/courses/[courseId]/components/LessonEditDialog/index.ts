export { default } from "./component";
