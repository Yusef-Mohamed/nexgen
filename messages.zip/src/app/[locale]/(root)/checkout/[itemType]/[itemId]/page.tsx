import MainComponent from "./component/MainComponent";
import { ICourse, ICoursePackage, IPackage } from "@/types";
import { createServerAxiosInstance } from "@/app/lib/serverUtils";
// export function generateMetadata({
//   params,
// }: {
//   params: { locale: string };
// }): Metadata {
//   return getMetadataCheckoutPage({
//     params,
//   });
// }
const getThisItem = async (
  itemType: "course" | "learning-path" | "service",
  itemId: string,
  locale: string,
) => {
  try {
    const axiosInstance = await createServerAxiosInstance({
      overRideLocale: locale,
    });
    if (itemType === "course") {
      const res = await axiosInstance.get(`/courses/${itemId}`);
      return res.data.data;
    } else if (itemType === "learning-path") {
      const res = await axiosInstance.get(`/coursePackages/${itemId}`);
      return res.data.data;
    } else if (itemType === "service") {
      const res = await axiosInstance.get(`/packages/${itemId}`);
      return res.data.data;
    } else return null;
  } catch (e) {
    console.error(e);
    return null;
  }
};
export type ItemType = "course" | "learning-path" | "service";
const CheckoutPage = async (props: {
  params: Promise<{
    locale: string;
    itemType: ItemType;
    itemId: string;
  }>;
}) => {
  const params = await props.params;

  const thisItem = (await getThisItem(
    params.itemType,
    params.itemId,
    params.locale,
  )) as ICourse | ICoursePackage | IPackage | null;
  return (
    <main>
      <MainComponent thisItem={thisItem} itemType={params.itemType} />
    </main>
  );
};

export default CheckoutPage;
