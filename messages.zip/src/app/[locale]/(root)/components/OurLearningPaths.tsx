"use client";

import React, { useState, useEffect, useRef } from "react";
import { useTranslations } from "next-intl";
import { ICoursePackage } from "@/types";
import { useCategoryFilter } from "@/hooks/useCategoryFilter";
import { useQuery } from "@tanstack/react-query";
import CategoryFilter from "./CategoryFilter";
import LearningPathsSubsection from "./LearningPathsSubsection";
import OneSidedContainer from "@/components/OneSidedContainer";
import SearchInput from "@/components/SearchInput";
import { useSearchParams } from "next/navigation";
import { axiosInstance } from "@/app/lib/utils";
import { usePathname, useRouter } from "@/i18n/navigation";
import { getDynamicString } from "@/lib/utils";
import SectionHeader from "@/components/SectionHeader";

interface OurLearningPathsProps {
  enableSearch?: boolean;
  gridClassName?: string;
  showAllCategories?: boolean;
}

const fetchLearningPathsByCategory = async (
  categoryId?: string,
  searchKeyword?: string,
): Promise<ICoursePackage[]> => {
  try {
    // First get all learning paths, then filter by category on the client side
    // since learning paths don't have a direct category field
    let url = "/coursePackages?limit=50";
    if (searchKeyword) {
      url += `&keyword=${encodeURIComponent(searchKeyword)}`;
    }
    const response = await axiosInstance.get(url);
    const allLearningPaths = response.data.data as ICoursePackage[];

    if (!categoryId) {
      return allLearningPaths.slice(0, 10);
    }

    // Filter learning paths that contain courses from the selected category
    const filteredLearningPaths = allLearningPaths.filter((learningPath) =>
      learningPath.courses.some(
        (course) => course.category?._id === categoryId,
      ),
    );

    return filteredLearningPaths.slice(0, 10);
  } catch (error) {
    console.error("Error fetching learning paths:", error);
    return [];
  }
};

const OurLearningPaths: React.FC<OurLearningPathsProps> = ({
  enableSearch = false,
  gridClassName = "",
  showAllCategories = enableSearch,
}) => {
  const text = useTranslations("learningPaths");
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();
  const currentQueryString = searchParams?.toString() || "";
  const containerRef = useRef<HTMLDivElement>(null);
  const [searchKeyword, setSearchKeyword] = useState(
    searchParams?.get("keyword") || "",
  );

  const {
    categories,
    loading: categoriesLoading,
    selectedCategory,
    setSelectedCategory,
  } = useCategoryFilter(enableSearch, !showAllCategories);

  // Update URL search params when search keyword changes
  useEffect(() => {
    if (!enableSearch) return;

    const params = new URLSearchParams(currentQueryString);
    if (searchKeyword) {
      params.set("keyword", searchKeyword);
    } else {
      params.delete("keyword");
    }

    const nextQueryString = params.toString();
    if (nextQueryString === currentQueryString) return;

    const newUrl = nextQueryString
      ? `${pathname}?${nextQueryString}`
      : pathname;
    router.replace(newUrl, { scroll: false });
  }, [searchKeyword, currentQueryString, pathname, router, enableSearch]);

  const { data: learningPaths = [], isLoading: learningPathsLoading } =
    useQuery({
      queryKey: ["learningPaths", selectedCategory?._id, searchKeyword],
      queryFn: () =>
        fetchLearningPathsByCategory(selectedCategory?._id, searchKeyword),
      enabled: showAllCategories && enableSearch ? true : !!selectedCategory,
      staleTime: 5 * 60 * 1000, // 5 minutes
      gcTime: 10 * 60 * 1000, // 10 minutes
    });

  // Generate localized title for the selected category
  const getCategoryTitle = () => {
    if (!selectedCategory) return undefined;
    return text("categoryTitle", {
      categoryName: getDynamicString(selectedCategory.title),
    });
  };

  return (
    <section className="py-12 space-y-8">
      <div className="container space-y-6" ref={containerRef}>
        <SectionHeader
          eyebrow={text("popularEyebrow")}
          heading={text("ourPopularLearningPaths")}
          description={text("heading")}
          tone="primary"
        />

        {/* Search Bar */}
        {enableSearch && (
          <SearchInput
            value={searchKeyword}
            onChange={setSearchKeyword}
            placeholder={text("searchLearningPaths")}
          />
        )}

        <CategoryFilter
          className="mb-2"
          categories={categories}
          selectedCategory={selectedCategory}
          onCategoryChange={setSelectedCategory}
          showAllButton={showAllCategories}
          loading={categoriesLoading}
        />
      </div>
      {enableSearch ? (
        <div className="container">
          <LearningPathsSubsection
            learningPaths={learningPaths}
            loading={learningPathsLoading}
            theme={"grid"}
            title={selectedCategory ? getCategoryTitle() : undefined}
            gridClassName={gridClassName}
            onCategoryClick={(category) => {
              setSelectedCategory(category);
              containerRef.current?.scrollIntoView({ behavior: "smooth" });
            }}
          />
        </div>
      ) : (
        <OneSidedContainer>
          <LearningPathsSubsection
            learningPaths={learningPaths}
            loading={learningPathsLoading}
            theme={"carousel"}
            title={selectedCategory ? getCategoryTitle() : undefined}
            gridClassName={gridClassName}
            onCategoryClick={(category) => {
              setSelectedCategory(category);
              containerRef.current?.scrollIntoView({ behavior: "smooth" });
            }}
          />
        </OneSidedContainer>
      )}{" "}
    </section>
  );
};

export default OurLearningPaths;
